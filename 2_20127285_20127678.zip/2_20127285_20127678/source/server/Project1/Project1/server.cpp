#include <vector>
#include <thread>
#include "data.h"

#pragma comment (lib, "Ws2_32.lib")

struct account
{
	std::string username;
	std::string pass;
};

account readline(std::string line_info)
{
	account a;
	std::stringstream s(line_info);
	std::string s1;

	std::getline(s, s1, ' ');
	a.username = s1;
	std::getline(s, s1);
	a.pass = s1;
	return a;
}

std::vector<account> readfile(std::string filename)
{
	std::vector<account> a;
	std::ifstream f(filename);
	if (f.is_open())
	{
		std::string line_info;
		while (!f.eof())
		{
			std::getline(f, line_info);
			a.push_back(readline(line_info));
		}
	}
	f.close();
	return a;
}

void writefile(std::string filename, std::vector<account> list)
{
	std::ofstream f(filename);
	if (f.is_open())
	{
		for (int i = 0; i < list.size(); i++)
		{
			f << list[i].username << " " << list[i].pass << std::endl;
		}
	}
	f.close();
}

void signin(SOCKET clientSocket, std::vector<account>  list, char* buf, int bytesReceived, bool& check)
{
	send(clientSocket, "Your username:", 15, 0);
	ZeroMemory(buf, 4096);
	bytesReceived = recv(clientSocket, buf, 4096, 0);

	std::string s = std::string(buf, 0, bytesReceived);
	int i = 0;

	while (i < list.size() && strcmp(list[i].username.c_str(), s.c_str()) != 0)
	{
		i++;
	}

	if (i>=list.size()) 
	{
		send(clientSocket, "Username doesn't exist!", 24, 0);
		check = false;
		return;
	}

	send(clientSocket, "Your password:", 15, 0);
	ZeroMemory(buf, 4096);
	bytesReceived = recv(clientSocket, buf, 4096, 0);

	s = std::string(buf, 0, bytesReceived);
	if (strcmp(list[i].pass.c_str(), s.c_str()) != 0)
	{
		send(clientSocket, "Wrong password!", 16, 0);
		check = false;
		return;
	}

	check = true;

	writefile("User.txt", list);

	send(clientSocket, "Logged in Successfully!", 24, 0);
}

void signup(SOCKET clientSocket, std::vector<account>& list, char* buf, int bytesReceived, bool& check)
{
	send(clientSocket, "Your username:", 15, 0);
	ZeroMemory(buf, 4096);
	bytesReceived = recv(clientSocket, buf, 4096, 0);

	std::string s = std::string(buf, 0, bytesReceived);
	int i = 0;

	while (i < list.size() && strcmp(list[i].username.c_str(), s.c_str()) != 0)
	{
		i++;
	}

	if (i < list.size())
	{
		send(clientSocket, "Username exists!", 17, 0);
		check = false;
		return;
	}

	account a;
	a.username = s;

	send(clientSocket, "Your password:", 15, 0);
	ZeroMemory(buf, 4096);
	bytesReceived = recv(clientSocket, buf, 4096, 0);

	s = std::string(buf, 0, bytesReceived);

	send(clientSocket, "Confirm your password:", 23, 0);
	ZeroMemory(buf, 4096);
	bytesReceived = recv(clientSocket, buf, 4096, 0);

	std::string s1 = std::string(buf, 0, bytesReceived);
	if (strcmp(s1.c_str(), s.c_str()) != 0)
	{
		send(clientSocket, "Password does not match!", 25, 0);
		check = false;
		return;
	}

	a.pass = s;
	list.push_back(a);
	check = true;

	writefile("User.txt", list);

	send(clientSocket, "Signed up Successfully!", 24, 0);
}

void takedata(HINTERNET connect, std::wstring API)
{
	while (true)
	{
		GetDataFromAPI(connect, L"//api/v2/exchange_rate/vcb?api_key=", API, "VIETCOMBANK");
		GetDataFromAPI(connect, L"//api/v2/exchange_rate/ctg?api_key=", API, "VIETINBANK");
		GetDataFromAPI(connect, L"//api/v2/exchange_rate/tcb?api_key=", API, "TECHCOMBANK");
		GetDataFromAPI(connect, L"//api/v2/exchange_rate/bid?api_key=", API, "BIDV");
		GetDataFromAPI(connect, L"//api/v2/exchange_rate/stb?api_key=", API, "SACOMBANK");
		GetDataFromAPI(connect, L"//api/v2/exchange_rate/sbv?api_key=", API, "SBV");
		std::cout << "UPDATE DATA DONE!" << "\n";
		Sleep(1800000);
	}
}

void searchdata(SOCKET clientSocket, char* buf, int bytesReceived)
{
	std::string bank, date, money;
	send(clientSocket, "Plz choose your bank:", 22, 0);
	ZeroMemory(buf, 4096);
	bytesReceived = recv(clientSocket, buf, 4096, 0);
	bank = std::string(buf, 0, bytesReceived);
	
	send(clientSocket, "Plz enter a day (dd-mm-yyyy):", 30, 0);
	ZeroMemory(buf, 4096);
	bytesReceived = recv(clientSocket, buf, 4096, 0);
	date = std::string(buf, 0, bytesReceived);
	
	send(clientSocket, "Plz enter the type of money:", 29, 0);
	ZeroMemory(buf, 4096);
	bytesReceived = recv(clientSocket, buf, 4096, 0);
	money = std::string(buf, 0, bytesReceived);

	readData(bank, date, money, clientSocket);
}

void chatclient(SOCKET clientSocket, char* buf, int bytesReceived)
{
	// While loop: accept and echo message back to client

	while (true)
	{
		ZeroMemory(buf, 4096);

		// Wait for client to send data
		int bytesReceived = recv(clientSocket, buf, 4096, 0);
		if (bytesReceived == SOCKET_ERROR)
		{
			std::cout << "Error in recv(). Quitting" << std::endl;
			break;
		}

		if (bytesReceived == 0)
		{
			std::cout << "Client disconnected " << std::endl;
			break;
		}

		std::cout << std::string(buf, 0, bytesReceived) << std::endl;

		// Echo message back to client
		if (strcmp(buf, "search") == 0) searchdata(clientSocket, buf, bytesReceived);
		else send(clientSocket, buf, bytesReceived + 1, 0);
	}
}

void clientjob(SOCKET clientSocket, char* buf, int bytesReceived, std::vector<account>  list, bool check)
{
	while (true)
	{
		send(clientSocket, "Sign in/Sign up:", 17, 0);
		ZeroMemory(buf, 4096);
		bytesReceived = recv(clientSocket, buf, 4096, 0);
		std::string s = std::string(buf, 0, bytesReceived);
		if (strcmp(s.c_str(), "sign in") == 0) signin(clientSocket, list, buf, bytesReceived, check);
		else if (strcmp(s.c_str(), "sign up") == 0) signup(clientSocket, list, buf, bytesReceived, check);
		if (check) break;
	}
	chatclient(clientSocket, buf, bytesReceived);
}

int main()
{
	// Initialze winsock
	WSADATA wsData;
	WORD ver = MAKEWORD(2, 2);

	int wsOk = WSAStartup(ver, &wsData);
	if (wsOk != 0)
	{
		std::cout << "Can't Initialize winsock! Quitting" << std::endl;
		return 1;
	}

	// Create a socket
	SOCKET listening = socket(AF_INET, SOCK_STREAM, 0);
	if (listening == INVALID_SOCKET)
	{
		std::cout << "Can't create a socket! Quitting" << std::endl;
		return 1;
	}

	// Bind the ip address and port to a socket
	sockaddr_in hint;
	hint.sin_family = AF_INET;
	hint.sin_port = htons(8080);
	hint.sin_addr.S_un.S_addr = INADDR_ANY; 

	bind(listening, (sockaddr*)&hint, sizeof(hint));

	// Tell Winsock the socket is for listening 
	listen(listening, SOMAXCONN);

	HINTERNET session = NULL, connect = NULL;
	session = WinHttpOpen(L"WinHTTP application/json HTTP/2.0", WINHTTP_ACCESS_TYPE_DEFAULT_PROXY, WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
	if (session)
	{
		connect = WinHttpConnect(session, L"vapi.vnappmob.com", INTERNET_DEFAULT_HTTPS_PORT, 0);
	}

	std::wstring API = getAPI(connect);

	std::thread t(takedata, connect, API);
	t.detach();

	std::vector<SOCKET> clientsocket;
	std::vector<std::thread> temp;
	std::vector<account> list = readfile("User.txt");
	char buf[4096];
	int bytesReceived;
	bool check;

	while (temp.size()<100)
	{
		sockaddr_in client;
		int clientSize = sizeof(client);

		SOCKET clientSocket = accept(listening, (sockaddr*)&client, &clientSize);
		
		char host[NI_MAXHOST];
		char service[NI_MAXSERV];

		ZeroMemory(host, NI_MAXHOST);
		ZeroMemory(service, NI_MAXSERV);

		if (getnameinfo((sockaddr*)&client, sizeof(client), host, NI_MAXHOST, service, NI_MAXSERV, 0) == 0)
		{
			std::cout << host << " connected on port " << service << std::endl;
		}
		else
		{
			inet_ntop(AF_INET, &client.sin_addr, host, NI_MAXHOST);
			std::cout << host << " connected on port " << ntohs(client.sin_port) << std::endl;
		}

		temp.push_back(std::thread(clientjob, clientSocket, buf, bytesReceived, list, check));
		temp.back().detach();
		clientsocket.push_back(clientSocket);
		
	}

	//Close the socket
	for (int i = 0; i < clientsocket.size(); i++)
	{
		send(clientsocket[i], "Server disconnected!", 21, 0);
		closesocket(clientsocket[i]);
	}

	// Close listening socket
	closesocket(listening);

	//Cleanup winsock
	WSACleanup();

	if (session) WinHttpCloseHandle(session);
	if (connect) WinHttpCloseHandle(connect);

	return 0;
}