#include "data.h"

void ToUpper(std::string& name)
{
	for (int i = 0; i < name.length(); i++)
	{
		if (name[i] >= 97 && name[i] <= 122)
		{
			name[i] -= 32;
		}
	}
}

void safeToFile(std::string time, std::string typesOfBank, std::string data) {
	_mkdir(typesOfBank.c_str());
	std::string filename = typesOfBank + "\\" + time + ".txt";
	std::fstream fout(filename, std::ios::out);
	fout << data;
	fout.close();
}

std::wstring getAPI(HINTERNET a)
{
	std::wstring link = L"/api/request_api_key?scope=exchange_rate";
	std::wstring temp = L"";
	HINTERNET request = WinHttpOpenRequest(a, L"GET", link.c_str(), NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
	bool result = WinHttpSendRequest(request, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0);
	bool response = WinHttpReceiveResponse(request, NULL);

	DWORD dwSize = 0;
	DWORD dwDownloadedd = 0;
	char* pszOutBuffer;

	if (response)
	{
		do
		{
			dwSize = 0;
			if (!WinHttpQueryDataAvailable(request, &dwSize))
			{
				std::cout << "Error in WinHttpQueryDataAvalable: " << GetLastError() << "\n";
			}

			pszOutBuffer = new char[dwSize + 1];

			if (!pszOutBuffer)
			{
				std::cout << "Out of memory\n";
				dwSize = 0;
			}
			else
			{
				ZeroMemory(pszOutBuffer, dwSize + 1);
				if (!WinHttpReadData(request, (LPVOID)pszOutBuffer, dwSize, &dwDownloadedd))
				{
					std::cout << "Error in WinHttpReadData: " << GetLastError() << "\n";
				}
				else
				{
					std::string temp1 = std::string(pszOutBuffer);
					temp += std::wstring(temp1.begin(), temp1.end());
				}

				delete[] pszOutBuffer;
			}
		} while (dwSize > 0);
	}

	if (!result) std::cout << "Error has occurred: " << GetLastError() << "\n";

	if (request) WinHttpCloseHandle(request);

	int start = 0, end = 0;
	for (int i = 0; i < 3; i++)
	{
		start = temp.find(L"\"", start + 1);
	}
	end = temp.length();
	wchar_t* result1 = new wchar_t[end - start + 1];
	temp.copy(result1, end - start - 4, start + 1);
	result1[end - start] = L'\0';

	return result1;
}

void GetDataFromAPI(HINTERNET a, std::wstring link, std::wstring API_KEY, std::string bankName)
{

	link += API_KEY;
	HINTERNET request = WinHttpOpenRequest(a, L"GET", link.c_str(), NULL, WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES, WINHTTP_FLAG_SECURE);
	bool result = WinHttpSendRequest(request, WINHTTP_NO_ADDITIONAL_HEADERS, 0, WINHTTP_NO_REQUEST_DATA, 0, 0, 0);
	bool response = WinHttpReceiveResponse(request, NULL);

	DWORD dwSize = 0;
	DWORD dwDownloadedd = 0;
	char* pszOutBuffer;
	std::string data;

	if (response)
	{
		do
		{
			dwSize = 0;
			if (!WinHttpQueryDataAvailable(request, &dwSize))
			{
				std::cout << "Error in WinHttpQueryDataAvalable: " << GetLastError() << "\n";
			}

			pszOutBuffer = new char[dwSize + 1];

			if (!pszOutBuffer)
			{
				std::cout << "Out of memory\n";
				dwSize = 0;
			}
			else
			{
				ZeroMemory(pszOutBuffer, dwSize + 1);
				if (!WinHttpReadData(request, (LPVOID)pszOutBuffer, dwSize, &dwDownloadedd))
				{
					std::cout << "Error in WinHttpReadData: " << GetLastError() << "\n";
				}
				else
				{
					data += pszOutBuffer;
				}

				delete[] pszOutBuffer;
			}
		} while (dwSize > 0);
	}

	if (!result) std::cout << "Error has occurred: " << GetLastError() << "\n";

	if (request) WinHttpCloseHandle(request);

	//to save data by day
	struct tm newtime;
	time_t present = time(0);
	localtime_s(&newtime, &present);

	std::string TIME = "";

	TIME += newtime.tm_mday > 9 ? std::to_string(newtime.tm_mday) : "0" + std::to_string(newtime.tm_mday);
	TIME += newtime.tm_mon > 9 ? std::to_string(1 + newtime.tm_mon) : "0" + std::to_string(1 + newtime.tm_mon);
	TIME += std::to_string(1900 + newtime.tm_year);

	safeToFile(TIME, bankName, data);

}

void readData(std::string bankName, std::string time, std::string money, SOCKET clientSocket)
{
	ToUpper(bankName);
	ToUpper(money);

	std::fstream fin(bankName + "/" + time + ".txt", std::ios::in);
	if (fin.fail()) {
		send(clientSocket, "Can't open!", 12, 0);
		return;
	}

	std::string data;
	getline(fin, data);

	Document d;
	d.Parse(data.c_str());

	const Value& array = d["results"];

	if (bankName != "SBV")
	{
		for (SizeType i = 0; i < array.Size(); i++)
		{
			if (array[i]["currency"].GetString() == money)
			{
				std::string s1 = array[i]["currency"].GetString();
				std::string s2 = std::to_string(array[i]["buy_cash"].GetDouble());
				std::string s3 = std::to_string(array[i]["buy_transfer"].GetDouble());
				std::string s4 = std::to_string(array[i]["sell"].GetDouble());
				
				std::string s = "\nCurrency: " + s1 + "\nBuy_cash: " + s2 + "\nBuy_transfer : " + s3 + "\nSell : " + s4 + "\n";
				send(clientSocket, s.c_str(), s.length() + 1, 0);
				return;
			}
		}
	}
	else 
	{
		for (SizeType i = 0; i < array.Size(); i++)
		{
			if (array[i]["currency"].GetString() == money);
			std::string s1 = array[i]["currency"].GetString();
			std::string s2 = std::to_string(array[i]["buy"].GetDouble());
			std::string s3 = std::to_string(array[i]["sell"].GetDouble());

			std::string s = "\nCurrency: " + s1 + "\nBuy: " + s2 + "\nSell: " + s3 + "\n";
			send(clientSocket, s.c_str(), s.length() + 1, 0);
			return;
		}
	}

	send(clientSocket, "Can't find!", 12, 0);

	fin.close();
}