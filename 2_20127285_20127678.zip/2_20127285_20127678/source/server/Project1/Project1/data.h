#ifndef _data_
#define _data_

#undef UNICODE
#define WIN32_LEAN_AND_MEAN

#include <iostream>
#include <windows.h>
#include <WinSock2.h>
#include <string>
#include <WS2tcpip.h>
#include <thread>
#include <sstream>
#include <winhttp.h>
#include <fstream>
#include <sql.h>
#include <windows.data.json.h>
#include <ctime>
#include <direct.h>
#include <WS2tcpip.h>
#include "rapidjson/document.h"

#pragma comment(lib,"Ws2_32.lib")
#pragma comment(lib, "Winhttp.lib")

using namespace rapidjson;

void ToUpper(std::string& name);
void safeToFile(std::string time, std::string typesOfBank, std::string data);
std::wstring getAPI(HINTERNET a);
void GetDataFromAPI(HINTERNET a, std::wstring link, std::wstring API_KEY, std::string bankName);
void readData(std::string bankName, std::string time, std::string money, SOCKET clientSocket);

#endif